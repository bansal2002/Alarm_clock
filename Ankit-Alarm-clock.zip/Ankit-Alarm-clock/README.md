# JS-Web-Clock
Javascript alarm clock and timer

TO DO:
- Alarm
-- Snooze
-- Mobile

- Timer Control
-- Simple timer with visual countdown. 
-- Standard alarm tone played
-- Count up or down toggle

-- Unit conversions
-- Sound choices

Next:
- Snooze accuracy
- Linear day counts
